Image Slider Maker README
=========================
ImageSliderMaker.com


Using in your website
---------------------

Please first make sure you have fully extracted the contents of the zip file.
In Windows, right-click on imageslidermaker.zip and select Extract All...

To get your slider working in your web page, you must add
my-slider.css, ism-2.2.min.js and the slide images to your project
directory and paste the markup (included below) into your HTML.

The directory structure of this package:

  imageslidermaker/
    README.txt
    example.html
    ism/
      css/
        my-slider.css
      js/
        ism-2.2.min.js
      image/
        slides/
          _u/1562519430391_718600.jpg
          _u/1562519429623_966891.jpg
          _u/1562519295718_903202.jpg
          _u/1562519294248_648748.jpg
          _u/1562519293766_661550.jpg
          background-2276_1280.jpg
          salad-652503_1280.jpg

For a working example, open example.html in your web browser or
follow the instructions below to integrate the slider into your
project.


Step by step instructions
-------------------------

1. Paste the following into the head of your HTML file:

<link rel="stylesheet" href="ism/css/my-slider.css"/>
<script src="ism/js/ism-2.2.min.js"></script>


2. Paste this into the body of your HTML file (at the location where:
   you would like your slider to appear in the page):

<div class="ism-slider" data-transition_type="zoom" data-play_type="once-rewind" id="my-slider">
  <ol>
    <li>
      <img src="ism/image/slides/_u/1562519430391_718600.jpg">
      <div class="ism-caption ism-caption-0">AYURVEDIC MEDICINES ARE THE BEST:)</div>
    </li>
    <li>
      <img src="ism/image/slides/_u/1562519429623_966891.jpg">
      <div class="ism-caption ism-caption-0">GROW MEDICINAL PLANTS:)</div>
    </li>
    <li>
      <img src="ism/image/slides/_u/1562519295718_903202.jpg">
      <div class="ism-caption ism-caption-0">USE HOME PRODUCTS:)</div>
    </li>
    <li>
      <img src="ism/image/slides/_u/1562519294248_648748.jpg">
      <div class="ism-caption ism-caption-0">CURE IS GAURENTEED:)</div>
    </li>
    <li>
      <img src="ism/image/slides/_u/1562519293766_661550.jpg">
      <div class="ism-caption ism-caption-0">DRINK GREEN TEA:)</div>
    </li>
    <li>
      <img src="ism/image/slides/background-2276_1280.jpg">
      <div class="ism-caption ism-caption-0">EAT FRUITS:)</div>
    </li>
    <li>
      <img src="ism/image/slides/salad-652503_1280.jpg">
      <div class="ism-caption ism-caption-0">EAT VEGGIES A LOT:)</div>
    </li>
  </ol>
</div>
<p class="ism-badge" id="my-slider-ism-badge"><a class="ism-link" href="http://imageslidermaker.com" rel="nofollow">generated with ISM</a></p>


3. Copy the ism/ directory into the root directory of your project.

   The css, js and image paths are relative, meaning the ism/
   directory should be in the same directory (path) as your HTML
   file containing the slider.


